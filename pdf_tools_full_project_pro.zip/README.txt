تم تجهيز الهيكلة الكاملة مع Traefik + Nginx + CI/CD.
